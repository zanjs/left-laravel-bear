<div class="range range-xs-center range-xs-middle range-md-justify">
    <div class="cell-sm-10 text-sm-left">
        <!-- List inline marked-->
        <ul class="list-inline list-marked list-marked-type-3 list-silver-chalice list-marked-silver-chalice font-accent text-bold text-spacing-inverse-25 text-left">
            <li><a href="#" class="text-turquoise">Super yachts</a></li>
            <li><a href="#" class="text-turquoise">Motor yachts</a></li>
            <li><a href="#" class="text-turquoise">Explorers</a></li>
            <li><a href="#" class="text-turquoise">Classic</a></li>
            <li><a href="#" class="text-turquoise">Sport fishers</a></li>
            <li><a href="#" class="text-turquoise">Day cruisers</a></li>
            <li><a href="#" class="text-turquoise">Go-faster</a></li>
        </ul>
    </div>
    <div class="cell-sm-2 text-sm-right product-switch-view">
        <div class="reveal-inline-block"><a href="yachts-grid.html"><span style="position:relative; top:1px;" class="icon material-icons-ico material-icons-view_module"></span></a></div>
        <div class="reveal-inline-block"><a href="yachts.html" class="active"><span class="icon material-icons-ico material-icons-view_list"></span></a></div>
    </div>
</div>