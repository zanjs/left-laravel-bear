@extends('layouts.app')

@section('title', ' ')

@section('content')

    @include('index.main')

@endsection